﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int Size = rnd.Next(10, 21);
            int[] Arr = new int[Size];
            textBox1.Text = Size.ToString();

            // fill 
            for (int i = 0; i< Arr.Length; i++)
            {
                Arr[i] = rnd.Next(100);
            }

            comboBox1.Items.Clear();
            foreach(int item in Arr)
            {
                comboBox1.Items.Add(item);
            }

            Array.Sort(Arr);

            listBox1.Items.Clear();
            foreach(int item in Arr)
            {
                listBox1.Items.Add(item);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int.TryParse(comboBox1.SelectedItem.ToString(), out int x);
            listBox1.SelectedItem = x;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int.TryParse(listBox1.SelectedItem.ToString(), out int x);
            comboBox1.SelectedItem = x;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
